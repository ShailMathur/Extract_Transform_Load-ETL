# Project2--Olympic-Track-and-Field-Insight

Group Members

David Wu

Donald Yakam

Huss Issa

Matt Kenney

Nwagbo Chidozie

Peter Drozdzewicz

Ricardo Benitez

Rodney Daverman

Shailja Mathur


For years, Olympics have been held around the world, and participants from around the world compete to succeed in different sports. We wanted to work with this data because we want to look for answers to the questions about which countries are superior in which branches, which countries are leading women or men in which sports and bringing medals to their country. 

For our data, we selected Track and Field data from the Olympic games over the last century. Dataset contains 2395 rows.
The Sources of our Data Set - https://www.kaggle.com/jayrav13/olympic-track-field-results?select=results.csv

The dataset contains various fields such as
Gender
Location
Event
Year
Medal
Name
Nationality
