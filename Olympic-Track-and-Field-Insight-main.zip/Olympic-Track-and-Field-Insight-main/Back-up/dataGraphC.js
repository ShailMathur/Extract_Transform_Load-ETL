var olympics=[
        {
            "level_0": "0",
            "index": "1717",
            "Nationality": "USA",
            "Year": "1928",
            "Medal": "G",
            "Event": "100M Women",
            "Gender": "W"
        },
        {
            "level_0": "1",
            "index": "1714",
            "Nationality": "USA",
            "Year": "1936",
            "Medal": "G",
            "Event": "100M Women",
            "Gender": "W"
        },
        {
            "level_0": "2",
            "index": "1708",
            "Nationality": "USA",
            "Year": "1960",
            "Medal": "G",
            "Event": "100M Women",
            "Gender": "W"
        },
        {
            "level_0": "3",
            "index": "1735",
            "Nationality": "USA",
            "Year": "1964",
            "Medal": "G",
            "Event": "100M Women",
            "Gender": "W"
        },
        {
            "level_0": "4",
            "index": "1705",
            "Nationality": "USA",
            "Year": "1968",
            "Medal": "G",
            "Event": "100M Women",
            "Gender": "W"
        },
        {
            "level_0": "5",
            "index": "1699",
            "Nationality": "USA",
            "Year": "1984",
            "Medal": "G",
            "Event": "100M Women",
            "Gender": "W"
        },
        {
            "level_0": "6",
            "index": "1696",
            "Nationality": "USA",
            "Year": "1992",
            "Medal": "G",
            "Event": "100M Women",
            "Gender": "W"
        },
        {
            "level_0": "7",
            "index": "1726",
            "Nationality": "USA",
            "Year": "1996",
            "Medal": "G",
            "Event": "100M Women",
            "Gender": "W"
        }
    ]