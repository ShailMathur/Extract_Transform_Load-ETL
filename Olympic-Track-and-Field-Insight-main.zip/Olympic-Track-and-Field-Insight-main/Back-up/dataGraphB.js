var olympics=[
    {
        "level_0": "0",
        "index": "147",
        "Nationality": "USA",
        "Year": "1896",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "1",
        "index": "108",
        "Nationality": "USA",
        "Year": "1900",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "2",
        "index": "144",
        "Nationality": "USA",
        "Year": "1904",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "3",
        "index": "141",
        "Nationality": "USA",
        "Year": "1912",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "4",
        "index": "102",
        "Nationality": "USA",
        "Year": "1920",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "5",
        "index": "135",
        "Nationality": "USA",
        "Year": "1932",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "6",
        "index": "96",
        "Nationality": "USA",
        "Year": "1936",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "7",
        "index": "132",
        "Nationality": "USA",
        "Year": "1948",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "8",
        "index": "93",
        "Nationality": "USA",
        "Year": "1952",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "9",
        "index": "129",
        "Nationality": "USA",
        "Year": "1956",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "10",
        "index": "126",
        "Nationality": "USA",
        "Year": "1964",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "11",
        "index": "87",
        "Nationality": "USA",
        "Year": "1968",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "12",
        "index": "81",
        "Nationality": "USA",
        "Year": "1984",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "13",
        "index": "75",
        "Nationality": "USA",
        "Year": "2000",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    },
    {
        "level_0": "14",
        "index": "114",
        "Nationality": "USA",
        "Year": "2004",
        "Medal": "G",
        "Event": "100M Men",
        "Gender": "M"
    }
]